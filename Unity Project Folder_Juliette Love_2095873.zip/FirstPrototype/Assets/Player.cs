﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public string playerName;
    public int attackPower;
    public int defenceNumber;
    public float currentHealth = 1;
    public int maxHealth;

    void Start()
    {

    }

    void Update()
    {

    }
}
