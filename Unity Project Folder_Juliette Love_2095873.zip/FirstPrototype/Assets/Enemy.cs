﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public string enemyName;
    public int attackPower;
    public int defenceNumber = 2;
    public float currentHealth;
    public float maxHealth = 1.0f;

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
